<?php require_once("header.php") ?>

	<div id="body">
		<div class="about">
			<h1>about</h1>
			<div>
				
			</div>
		</div>
	</div>

<?php require_once("footer.php") ?>
