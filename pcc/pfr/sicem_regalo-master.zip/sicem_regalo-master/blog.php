<!DOCTYPE html>
<!-- Template by freewebsitetemplates.com -->
<html>
<head>
<meta charset="utf-8" />
<title>Business Solutions</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
</head>
<body>
	<div id="header">
			<div id="logo">
				<a href="index.html"><img src="images/logo.jpg" alt="" /></a>			
			</div>		
			<ul>
				<li><a href="index.html"><span>home</span></a></li>
				<li><a href="about.html"><span>about us</span></a></li>
				<li><a href="services.html"><span>services</span></a></li>
				<li><a href="products.html"><span>products</span></a></li>
				<li><a href="contact.html"><span>contact us</span></a></li>			
			</ul>
	</div>
	<div id="body">
		<div class="blog">
			<h1>blog</h1>
			<div>
				<h2>We Have Free Templates for Everyone:</h2>
				<p class="article">Our website templates are created with inspiration, checked for quality and originality and meticulously sliced and coded. What’s more, they’re absolutely free! You can do a lot with them. You can modify them. You can use them to design websites for clients, so long as you agree with the <a href="http://www.freewebsitetemplates.com/about/termsofuse/">Terms of Use</a>. You can even remove all our links if you want to.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut turpis vitae purus cursus malesuada at sed lacus. Integer pretium luctus felis, a dictum dui malesuada in. Praesent nunc erat, mollis sed varius id, blandit ut nisi. Aliquam in ipsum purus, in dignissim turpis. Nullam a adipiscing felis. Etiam a egestas dui. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nunc eu neque vel velit fringilla placerat at eu nulla. Sed tempus metus a lectus tristique in malesuada dolor mollis. Praesent nisl leo, aliquet elementum ullamcorper ut, accumsan et justo. Curabitur porttitor, dolor dapibus sodales tristique, nisi dui interdum lorem, et bibendum nisi massa ac magna. Donec vitae velit nec metus faucibus aliquam. Donec at ligula sem, sit amet euismod turpis. In ac augue sed orci ultrices mollis ut ut felis. Quisque condimentum facilisis velit, vel sollicitudin ligula lobortis eget.  Nulla ut metus nulla. Proin vulputate tristique feugiat. Nulla et dui est, a scelerisque turpis. Ut id augue velit. Morbi lobortis quam aliquam felis commodo hendrerit. Nulla sit amet velit iaculis sem tempor mattis id nec augue. Curabitur eleifend tempus quam, condimentum mollis massa rhoncus sed. Curabitur vel lacus mauris. Phasellus id ligula a felis scelerisque tempor. Mauris in odio ligula. Duis sit amet euismod neque. Aenean consectetur pulvinar enim nec lobortis. Donec eget enim purus. Pellentesque a elit enim, non vestibulum nulla. Curabitur in nunc porttitor leo eleifend congue in vitae velit. Nulla at nunc nunc. Nulla facilisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur convallis placerat semper. Praesent sit amet ultricies mauris. Maecenas sed lectus vitae mauris tempus convallis quis at metus.</p>
				<p>This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forum">Forum</a>.</p>
			</div>
			<ul>
				<li>
					<h3>This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free.</h3>	
					<p>You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us.</p>			
				</li>
				<li>
					<h3>Nulla ut metus nulla vulputate tristique</h3>			
					<p>Pellentesque non vestibulum nulla. Curabitur in nunc porttitor leo eleifend congue in vitae velit. Nulla at nunc nunc. Nulla facilisi. </p>
				</li>
				<li>
					<h3>If you're having problems editing this website template,</h3>
					<p>then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forum">Forum</a>.</p>
				</li>
				<li>
					<h3>Looking for more templates?</h3>
					<p>Just browse through all our <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> and find what you’re looking for. But if you don’t find any website template you can use, you can try our <a href="http://www.freewebsitetemplates.com/freewebdesign/">Free Web Design</a> service and tell us all about it</p>
				</li>
				<li>
					<h3>Class aptent taciti sociosqu </h3>
					<p>Vestibulum pretium consectetur lectus, in porta eros mattis at. Pellentesque in tortor nec metus blandit pellentesque.</p>
				</li>
			</ul>
		</div>
	</div>
		<div id="footer">
			<div>
				<div>
					<h3>america</h3>
					<ul>
						<li>457-380-1654 main</li>				
						<li>257-301-9417 toll free</li>
					</ul>			
				</div>		
				<div>
					<h3>europe</h3>
					<ul>
						<li>457-380-1654 main</li>				
						<li>257-301-9417 toll free</li>
					</ul>			
				</div>	
				<div>
					<h3>canada</h3>
					<ul>
						<li>457-380-1654 main</li>				
						<li>257-301-9417 toll free</li>
					</ul>			
				</div>	
				<div>
					<h3>middle east</h3>
					<ul>
						<li>457-380-1654 main</li>				
						<li>257-301-9417 toll free</li>
					</ul>			
				</div>	
				<div>
					<h3>follow us:</h3>
					<a class="facebook" href="http://facebook.com/freewebsitetemplates" target="_blank">facebook</a>		
					<a class="twitter" href="http://twitter.com/fwtemplates" target="_blank">twitter</a>
				</div>	
			</div>
			<div>
				<p>&copy Copyright 2012. All rights reserved</p>
			</div>
		</div>
	</body>
</html>