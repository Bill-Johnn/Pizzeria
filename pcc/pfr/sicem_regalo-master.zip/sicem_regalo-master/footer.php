<div id="footer">
			<div>
				<div>
					<h3>BINARIO CONSULTORES</h3>
					<ul>
						<li>Calle Blondell 105 - Miraflores</li>				
						<li>RPC: 974 - 204853</li>
					</ul>			
				</div>		
				
				<div>
					<h3>Síguenos:</h3>
					<a class="facebook" href="https://www.facebook.com/jorgegarnicablanco" target="_blank">facebook</a>
				</div>	
			</div>
			<div>
				<p>Todos los Derechos Reservados - 2016</p>
			</div>
		</div>
	</body>
</html>