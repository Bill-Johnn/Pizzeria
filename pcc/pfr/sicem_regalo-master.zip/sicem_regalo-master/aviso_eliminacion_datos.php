<?php require_once("header_admin.php") ?>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script type="text/javascript" src="formly.js"></script>
<link rel="stylesheet" href="formly.css" type="text/css" />
</script>

                
    <div id="body">
		<div class="cem">
			<h8>ELIMINACION TOTAL  -  EXITOSA!</h8>
            

           <form method=post id="BetaSignup7" action="nichos_seleccion.php" width="200px"  title="REGRESAR" >

                        <input type=submit  name=xenvio  value="Regresar"  >
                        
                        </form>
                        
                        
    </div></div>
    
 <script>
 $(document).ready(function()
{ $('#BetaSignup7').formly({'onBlur':false, 'theme':'Light'}); });
</script>      
                

<?php require_once("footer.php") ?>